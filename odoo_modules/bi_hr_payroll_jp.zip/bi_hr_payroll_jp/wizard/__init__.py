# -*- coding: utf-8 -*-

from . import hr_insurance_rate_import
