# -*- coding: utf-8 -*-

from . import hr_insurance_prefecture
from . import hr_insurance_rate
from . import hr_insurance_grade
from . import hr_withholding_tax
from . import hr_employee
from . import res_company

# hr_payslip extension requires hr_payroll module
# Uncomment when hr_payroll is installed:
# from . import hr_payslip
